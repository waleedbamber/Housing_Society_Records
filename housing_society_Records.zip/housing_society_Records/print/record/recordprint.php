<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_Records";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">*************RECORD(Table) Print **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Seller_id</th>
<th>Buyer_id</th>
<th>Plot_id	</th>
<th>Transfer_Date</th>
<th>Plot_Number</th>
<th>Plot_Type</th>
<th>Plot_Size</th>
<th>Selling_Rate</th>
<th>Buying_Rate</th>
<th>Username</th>

</tr>
<?php
$sql = "SELECT * FROM Record";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Seller_id'];?></td>
<td> <?php  echo $row['Buyer_id'];?></td>
<td> <?php  echo $row['Plot_id'];?></td>
<td> <?php  echo $row['Transfer_Date'];?></td>
<td> <?php  echo $row['Plot_Number'];?></td>
<td> <?php  echo $row['Plot_Type'];?></td>
<td> <?php  echo $row['Plot_Size'];?></td>
<td> <?php  echo $row['Selling_Rate'];?></td>
<td> <?php  echo $row['Buying_Rate'];?></td>
<td> <?php  echo $row['Username'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>