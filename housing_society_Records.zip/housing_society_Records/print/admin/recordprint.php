<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_Records";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">*************Admin RECORD Print **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Username</th>
<th>Fname</th>
<th>Lname</th>
<th>Password</th>


</tr>
<?php
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['Username'];?></td>
<td> <?php  echo $row['Password'];?></td>

 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>