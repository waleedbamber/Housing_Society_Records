<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_Records";// 1st change database name

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
	
 $sql = "SELECT * FROM plot WHERE Plot_id=" .$_GET['edit_id'];
 // 2nd change table name and carno ya id jis ko ap change krna chaho
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_array($result);

}
if(isset($_POST['btn-update'])){
$a= $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];
$e = $_POST['e'];
$f = $_POST['f'];
$g=$_POST['g'];
 
// 3rd pa neechy jao or table k column name change kro
// 4th number pay yaha pay car_category ki jaga table name likho
 $update = "UPDATE plot SET PlotNumber='$b', Size='$c'  , Rate='$d' , Type='$e' , buyer_id='$f' , seller_id='$g' where Plot_id='$a' ";
if ($conn->query($update) === TRUE) {
    echo "<script>alert('Do you want To update Record ?');</script>";
} else {
    echo "Error: " . $update . "<br>" . $conn->error;
}
}
?>
<!doctype html>
<html>
<head>


</head>


<body>

<form method="post">
<h1>Update Record</h1>
<input type="text" name="a" placeholder="Plot_id" value="<?php echo $row['Plot_id']; ?>"><br>
<input type="text"  name="b" placeholder="PlotNumber" value="<?php echo $row['PlotNumber']; ?>"><br>
<input type="text"  name="c" placeholder="Size" value="<?php echo $row['Size']; ?>"><br>
<input type="text" name="d" placeholder="Rate" value="<?php echo $row['Rate']; ?>"><br>
<input type="text"  name="e" placeholder="Type" value="<?php echo $row['Type']; ?>"><br>
<input type="text"  name="f" placeholder="Buyer_id" value="<?php echo $row['Buyer_id']; ?>"><br>
<input type="text"  name="g" placeholder="Seller_id" value="<?php echo $row['Seller_id']; ?>"><br>

<button type="submit" name="btn-update" id="btn-update" ><strong>Update</strong></button>
<a href="record.php"><button type="button" value="button">Cancel</button></a>
</form>

</body>
</html>