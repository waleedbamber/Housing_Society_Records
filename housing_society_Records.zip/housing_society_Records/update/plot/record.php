<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_Records";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Plot(Table) Record Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Plot_id</th>
<th>PlotNumber</th>
<th>Size</th>
<th>Rate</th>
<th>Type</th>
<th>Buyer_id</th>
<th>Seller_id</th>

</tr>
<?php
$sql = "SELECT * FROM Plot";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Plot_id'];?></td>
<td> <?php  echo $row['PlotNumber'];?></td>
<td> <?php  echo $row['Size'];?></td>
<td> <?php  echo $row['Rate'];?></td>
<td> <?php  echo $row['Type'];?></td>
<td> <?php  echo $row['Buyer_id'];?></td>
<td> <?php  echo $row['Seller_id'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['Plot_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>