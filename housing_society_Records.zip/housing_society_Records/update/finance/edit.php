<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_records";// 1st change database name

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
	
 $sql = "SELECT * FROM finance WHERE Plot_id=" .$_GET['edit_id'];
 // 2nd change table name and carno ya id jis ko ap change krna chaho
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_array($result);

}
if(isset($_POST['btn-update'])){
 $a= $_POST['a'];
 $b = $_POST['b'];
 $c = $_POST['c'];
  $d = $_POST['d'];
 
// 3rd pa neechy jao or table k column name change kro
// 4th number pay yaha pay car_category ki jaga table name likho
 $update = "UPDATE car_category SET Buying_Rate	='$b', Selling_Rate='$c'  , Username='$d' where Plot_id='$a' ";
if ($conn->query($update) === TRUE) {
    echo "<script>alert('Do you want To update Record ?');</script>";
} else {
    echo "Error: " . $update . "<br>" . $conn->error;
}
}
?>
<!doctype html>
<html>
<head>


</head>


<body>

<form method="post">
<h1>Update Record</h1>
<input type="text" name="a" placeholder="Plot_id" value="<?php echo $row['Plot_id']; ?>"><br>
<input type="text"  name="b" placeholder="Buying_Rate" value="<?php echo $row['Buying_Rate']; ?>"><br>
<input type="text"  name="c" placeholder="Selling_Rate" value="<?php echo $row['Selling_Rate']; ?>"><br>
<input type="text" name="d" placeholder="Username" value="<?php echo $row['Username']; ?>"><br>

<button type="submit" name="btn-update" id="btn-update" ><strong>Update</strong></button>
<a href="record.php"><button type="button" value="button">Cancel</button></a>
</form>

</body>
</html>