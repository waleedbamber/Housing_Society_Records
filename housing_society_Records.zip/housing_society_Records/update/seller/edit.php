<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Housing_society_Records";// 1st change database name

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
	
 $sql = "SELECT * FROM seller WHERE Seller_id=" .$_GET['edit_id'];
 // 2nd change table name and carno ya id jis ko ap change krna chaho
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_array($result);

}
if(isset($_POST['btn-update'])){
 $a= $_POST['a'];
 $b = $_POST['b'];
 $c = $_POST['c'];
  $d = $_POST['d'];
  $e = $_POST['e'];
	$f = $_POST['f'];
	$f = $_POST['g'];
 
// 3rd pa neechy jao or table k column name change kro
// 4th number pay yaha pay car_category ki jaga table name likho
 $update = "UPDATE seller SET Plot_id='$b', Fname='$c'  , Lname='$d' , CNIC	='$e' , Address='$f', Phone_Number='$g' where Seller_id='$a' ";
if ($conn->query($update) === TRUE) {
    echo "<script>alert('Do you want To update Record ?');</script>";
} else {
    echo "Error: " . $update . "<br>" . $conn->error;
}
}
?>
<!doctype html>
<html>
<head>


</head>


<body>

<form method="post">
<h1>Update Record</h1>
<input type="text" name="a" placeholder="Seller_id" value="<?php echo $row['Seller_id']; ?>"><br>
<input type="text"  name="b" placeholder="Plot_id" value="<?php echo $row['Plot_id']; ?>"><br>
<input type="text"  name="c" placeholder="Fname" value="<?php echo $row['Fname']; ?>"><br>
<input type="text" name="d" placeholder="Lname" value="<?php echo $row['Lname']; ?>"><br>
<input type="text"  name="e" placeholder="CNIC" value="<?php echo $row['CNIC']; ?>"><br>
<input type="text"  name="f" placeholder="Address" value="<?php echo $row['Address']; ?>"><br>
<input type="text"  name="g" placeholder="Phone_Number" value="<?php echo $row['Phone_Number']; ?>"><br>

<button type="submit" name="btn-update" id="btn-update" ><strong>Update</strong></button>
<a href="record.php"><button type="button" value="button">Cancel</button></a>
</form>

</body>
</html>