<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housing_society_records";

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
 $sql = "DELETE FROM seller WHERE Seller_id=" .$_GET['edit_id'];
 $result = mysqli_query($conn, $sql);
 

}

?>
<!doctype html>
<html>
<head>


</head>


<body>

<h1 align="center">Deleted RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Plot_id</th>
<th>Seller_id</th>
<th>Fname</th>
<th>Lname</th>
<th>CNIC</th>
<th>Address</th>
<th>Phone_Number</th>

</tr>
<?php
$sql = "SELECT * FROM seller";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Plot_id'];?></td>
<td> <?php  echo $row['Seller_id'];?></td>
<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['CNIC'];?></td>
<td> <?php  echo $row['Address'];?></td>
<td> <?php  echo $row['Phone_Number'];?></td>


 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>

</body>
</html>