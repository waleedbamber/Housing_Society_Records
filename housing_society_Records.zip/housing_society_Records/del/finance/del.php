<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housing_society_records";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>


</head>
<body>

<h1 align="center">Delete Finance RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Plot_id</th>
<th>Buying_Rate</th>
<th>Selling_Rate</th>
<th>Username</th>


<?php
$sql = "SELECT * FROM Finance";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Plot_id'];?></td>
<td> <?php  echo $row['Buying_Rate'];?></td>
<td> <?php  echo $row['Selling_Rate'];?></td>
<td> <?php  echo $row['Username'];?></td>



 <td><a href="delete.php?edit_id=<?php echo $row['Username']; ?>" alt="edit" >Delete Record</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>